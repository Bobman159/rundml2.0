/**
 * Define classes to build SQL statements on different DBMS platforms.
 */
package com.bobman159.rundml.sql;