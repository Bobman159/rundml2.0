package com.bobman159.rundml.sql.h2;
/**
 * API definitions for creation and building H2 database SQL statements.
 */