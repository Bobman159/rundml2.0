/**
 * Define SQL statement builders that should execute on different databases.
 */
package com.bobman159.rundml.sql.base.builder;